import os

from MelodieStudio import studio_main
from config import config

studio_main(config)
