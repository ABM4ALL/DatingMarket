from Melodie import DataCollector


class _ALIAS_DataCollector(DataCollector):
    def setup(self):
        pass
