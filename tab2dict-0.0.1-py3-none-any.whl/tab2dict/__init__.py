from .tab_dict import TabDict
from .tab_dict import TabKey
